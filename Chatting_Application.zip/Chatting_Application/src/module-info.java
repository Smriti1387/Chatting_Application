module Chatting_Application {
	requires java.desktop;
}